# Chess-Game-
A simple and complete chess game made in C# using OOP concepts , an AI with MINIMAX ALgorihtm with alpha beta bruning.
